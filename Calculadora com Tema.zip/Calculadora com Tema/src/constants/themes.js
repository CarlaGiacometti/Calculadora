export const themes = {
  'Default': {
    id: '1',
    colors: [
      { name: '--background', value: '#3a4764' },
      { name: '--background-dark', value: '#232c43' },
      { name: '--background-very-dark', value: '#182034' },
      { name: '--key-color-top', value: '#ffffff' },
      { name: '--key-color-bottom', value: '#3a4764' },
      { name: '--key-background', value: '#eae3dc' },
      { name: '--key-background-dark', value: '#dfd9d2' },
      { name: '--key-shadow', value: '#b4a597' },
      { name: '--key-blue-background', value: '#ff9603' },
      { name: '--key-blue-shadow', value: '#ff9603' },
      { name: '--key-red-background', value: '#ff9603' },
      { name: '--key-red-shadow', value: '#ff9603' },
    ]
  },
  'Light': {
    id: '2',
    colors: [
      { name: '--background', value: '#e6e6e6' },
      { name: '--background-dark', value: '#d3cdcd' },
      { name: '--background-very-dark', value: '#eeeeee' },
      { name: '--key-color-top', value: '#3d3d33' },
      { name: '--key-color-bottom', value: '#3d3d33' },
      { name: '--key-background', value: '#e5e4e0' },
      { name: '--key-background-dark', value: '#dfd9d2' },
      { name: '--key-shadow', value: '#b4a597' },
      { name: '--key-blue-background', value: '#db4654' },
      { name: '--key-blue-shadow', value: '#db4654' },
      { name: '--key-red-background', value: '#db4654' },
      { name: '--key-red-shadow', value: '#db4654' },
    ]
  },
  'Dark': {
    id: '3',
    colors: [
      { name: '--background', value: '#212121' },
      { name: '--background-dark', value: '#181818' },
      { name: '--background-very-dark', value: '#181818' },
      { name: '--key-color-top', value: 'white' },
      { name: '--key-color-bottom', value: 'white' },
      { name: '--key-background', value: '#2d4971' },
      { name: '--key-shadow', value: '#2d4971' },
      { name: '--key-blue-background', value: '#0d6efd' },
      { name: '--key-blue-shadow', value: '#0d6efd' },
      { name: '--key-red-background', value: '#0d6efd' },
      { name: '--key-red-shadow', value: '#0d6efd' },
    ]
  }
}
